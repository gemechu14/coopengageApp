// ignore_for_file: use_key_in_widget_constructors

import 'package:coopengageplus/customerOnboarding/CorporateAccountOpening/providers/stepper_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:coopengageplus/features/onboarding/JointNationalIdentification/providers/stepper_provider.dart';
import 'package:coopengageplus/common_widgets/dropDown/branch_selector.dart';
import 'package:coopengageplus/widget/ReusableTextFormField.dart';

import 'package:coopengageplus/constants/listConstants.dart';
import 'package:coopengageplus/common_widgets/dropDown/ReusableDropdown.dart';

class BranchAndDepositStep extends ConsumerStatefulWidget {
  final GlobalKey<FormState>? formkey;

  const BranchAndDepositStep({Key? key, this.formkey}) : super(key: key);

  @override
  ConsumerState<BranchAndDepositStep> createState() =>
      _BranchAndDepositStepState();
}

class _BranchAndDepositStepState extends ConsumerState<BranchAndDepositStep> {
  late TextEditingController initialDepositController;
  final TextEditingController cityController = TextEditingController();
  final TextEditingController woredaController = TextEditingController();
  final TextEditingController residenceController = TextEditingController();
  String? selectedState;
  String? selectedNumberOfMembers;
  bool isUserEditing = false;

  // Method to validate the form - can be called from parent
  bool validateForm() {
    final stepperState = ref.read(stepperProvider);
    
    // Check if form is valid
    final isFormValid = widget.formkey?.currentState?.validate() ?? false;
    
    // Check required fields from provider state
    final hasBranch = stepperState.selectedBranch != null;
    final hasInitialDeposit = stepperState.initialDeposit != null && stepperState.initialDeposit! > 0;
    
    return isFormValid && hasBranch && hasInitialDeposit;
  }

  // Method to get validation errors
  List<String> getValidationErrors() {
    final stepperState = ref.read(stepperProvider);
    List<String> errors = [];
    
    if (stepperState.selectedBranch == null) {
      errors.add('Please select a branch');
    }
    if (stepperState.initialDeposit == null || stepperState.initialDeposit! <= 0) {
      errors.add('Please enter initial deposit amount');
    }
    
    return errors;
  }

  // Method to trigger validation and show errors
  void triggerValidation() {
    // Trigger form validation
    widget.formkey?.currentState?.validate();
  }

  @override
  void initState() {
    super.initState();
    final stepperState = ref.read(stepperProvider);
    initialDepositController = TextEditingController(
      text: stepperState.initialDeposit != null &&
              stepperState.initialDeposit! > 0
          ? stepperState.initialDeposit!.toInt().toString()
          : '',
    );

    // Add listener to reset editing flag when user stops editing
    initialDepositController.addListener(() {
      // Reset editing flag after a short delay to allow for user input
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) {
          setState(() {
            isUserEditing = false;
          });
        }
      });
    });

    selectedState = stepperState.companyState;
    selectedNumberOfMembers = stepperState.numberOfMembers.toString();
  }

  @override
  void didUpdateWidget(BranchAndDepositStep oldWidget) {
    super.didUpdateWidget(oldWidget);
    final stepperState = ref.read(stepperProvider);

    // Don't update if user is actively editing
    if (isUserEditing) {
      return;
    }

    final newText =
        stepperState.initialDeposit != null && stepperState.initialDeposit! > 0
            ? stepperState.initialDeposit!.toInt().toString()
            : '';

    if (initialDepositController.text != newText) {
      initialDepositController.text = newText;
    }
    selectedState = stepperState.companyState;
    selectedNumberOfMembers = stepperState.numberOfMembers.toString();
  }

  @override
  void dispose() {
    initialDepositController.dispose();
    cityController.dispose();
    woredaController.dispose();
    residenceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final stepperState = ref.watch(stepperProvider);
    final notifier = ref.read(stepperProvider.notifier);

    // Sync controller values with provider state (add these fields to provider if not present)
    if (cityController.text != (stepperState.companyZoneSubCity ?? '')) {
      cityController.text = stepperState.companyZoneSubCity ?? '';
    }
    if (woredaController.text != (stepperState.companyWoreda ?? '')) {
      woredaController.text = stepperState.companyWoreda ?? '';
    }
    return Padding(
      padding: const EdgeInsets.all(1.0),
      child: Form(
        key: widget.formkey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Branch', style: TextStyle(fontWeight: FontWeight.bold)),
            BranchSelector(
              initialValue: stepperState.selectedBranch,
              onChanged: (value) {
                notifier.updateBranch(value);
              },
            ),
            SizedBox(height: 10),
            Text('Number of Authorized Signers',
                style: TextStyle(fontWeight: FontWeight.bold)),
            ReusableDropdown(
              selectedValue: selectedNumberOfMembers,
              items: ListContants.NumberOfMembersForOrganization,
              hintText: 'Select Number of Authorized Signers',
              onChanged: (newValue) {
                setState(() {
                  selectedNumberOfMembers = newValue;
                });
                final parsed = int.tryParse(newValue ?? '');
                if (parsed != null) {
                  notifier.updateNumberOfMembers(parsed);
                }
              },
              errorMessage: 'Please select number of authorized signers',
              prefixIcon: Icons.group,
              isRequired: false,
            ),
            Text('Initial Deposit',
                style: TextStyle(fontWeight: FontWeight.bold)),
            ReusableTextFormField(
              hintText: 'Initial Deposit',
              controller: initialDepositController,
              keyboardType: TextInputType.number,
              errorMessage: 'Initial Deposit cannot be empty',
              leadingIcon: Icons.account_balance_wallet,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              ],
              isRequired: true,
              onChanged: (value) {
                // Set editing flag
                isUserEditing = true;

                // Handle empty value
                if (value.isEmpty) {
                  notifier.updateInitialDeposit(null);
                  return;
                }

                // Only allow integer values
                final intValue = int.tryParse(value);
                notifier.updateInitialDeposit(intValue?.toDouble());
              },
            ),
            const SizedBox(height: 16),
            Text('State', style: TextStyle(fontWeight: FontWeight.bold)),
            ReusableDropdown(
              selectedValue: selectedState,
              items: ListContants.ethiopianStates,
              hintText: 'Select State',
              onChanged: (newState) {
                setState(() {
                  selectedState = newState;
                });
                notifier.updateCompanyState(newState);
              },
              errorMessage: 'Please select a state',
              prefixIcon: Icons.map,
              isRequired: false,
            ),
            Text('Zone Subcity', style: TextStyle(fontWeight: FontWeight.bold)),
            ReusableTextFormField(
              hintText: "Zone Subcity",
              controller: cityController,
              errorMessage: "Zone Subcity cannot be empty",
              leadingIcon: Icons.location_city,
              isRequired: false,
              onChanged: (value) {
                notifier.updateCompanyZoneSubCity(value);
              },
            ),
            Text('Woreda', style: TextStyle(fontWeight: FontWeight.bold)),
            ReusableTextFormField(
              hintText: "Woreda",
              controller: woredaController,
              errorMessage: "Woreda cannot be empty",
              leadingIcon: Icons.location_city,
              isRequired: false,
              onChanged: (value) {
                notifier.updateCompanyWoreda(value);
              },
            ),
            // Text('Resident', style: TextStyle(fontWeight: FontWeight.bold)),
            // ReusableTextFormField(
            //   hintText: "Resident ",
            //   controller: residenceController,
            //   keyboardType: TextInputType.text,
            //   errorMessage: "Resident cannot be empty",
            //   leadingIcon: Icons.location_city,
            //   isRequired: true,
            //   onChanged: (value) {
            //     // If you have an updateResident method, use it here
            //     // notifier.updateResident(value);
            //   },
            // ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
